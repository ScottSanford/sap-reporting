angular.module('reporting').factory("reportingInitialData", function($http, $q, CSVConverterService) {
    return function() {
        var deferred = $q.defer();
        mflyCommands.getData('9e8791d09fc148878d3b2e177ed2b5d7product165418').done(function(data){	
            deferred.resolve(CSVConverterService.csvToJSON(data));
        })
        // $http.get('data/ViewsByUserActivity_01.01.2015_02.18.2015.xls')
        //  .success(function (data) {
        //  	 deferred.resolve(CSVConverterService.csvToJSON(data));
        // });
    return deferred.promise;
    }
});