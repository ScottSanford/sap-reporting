angular.module('reporting').factory("registeredUsersData", function($http, $q, CSVConverterRegisteredUsers) {
    var self = {};

	var deferred = $q.defer();
			// dynamically get data from Airship
	        mflyCommands.getData('9e8791d09fc148878d3b2e177ed2b5d7product166447').done(function(data){	
            	deferred.resolve(CSVConverterRegisteredUsers.csvToJSON(data));
        	})
    // $http.get('data/2-18-2015_Ariba_Saleskit_users.xls')
    //  .success(function (data) {
    //     deferred.resolve(CSVConverterRegisteredUsers.csvToJSON(data));
    // });
	self.registeredUsers = deferred.promise;

    return self; 

});